#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
	
#define PORT 8080
#define MAXLINE 50
	
// Driver code
int main(int argc, char *argv[]) {
    char* serveraddress_str;
    char* serverport_str;

    if (argc != 3) {
        fprintf(stderr, "Użycie: %s <server IP> <server port>\n Zastosowano domyślne ustawienia 127.0.0.1:8080", argv[0]);
        serveraddress_str = "127.0.0.1";
        serverport_str="8080";
    }
    else{
        serveraddress_str = argv[1];
        serverport_str = argv[2];
    }

	int sockfd;
	char buffer[MAXLINE];
	char hello[MAXLINE];
	struct sockaddr_in	 servaddr;
	
	// Creating socket file descriptor
	if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
		perror("socket creation failed");
		exit(EXIT_FAILURE);
	}
	
	memset(&servaddr, 0, sizeof(servaddr));
		
	// Filling server information
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(atoi(serverport_str));
    if (inet_pton(AF_INET, serveraddress_str, &servaddr.sin_addr) <= 0) {
        perror("inet_pton failed");
        exit(EXIT_FAILURE);
    }
		
	int n, len;

	pid_t child_pid = fork();
	if (child_pid == 0) {
		// Child
		while(1){
            len = sizeof(servaddr);
            memset(buffer, 0, sizeof(buffer));
			n = recvfrom(sockfd, (char *)buffer, MAXLINE,
						MSG_WAITALL, (struct sockaddr *) &servaddr,
						&len);
			buffer[n] = '\0';
			printf("Nowa wiadomość : %s\n", buffer);
		}
	} else {
		// Parent
		while(1){
            scanf(" %[^\n]s", hello); // do znaku nowej lini czytaj wszystko
			sendto(sockfd, (const char *)hello, strlen(hello),
			MSG_CONFIRM, (const struct sockaddr *) &servaddr,
				sizeof(servaddr));
		}
	}
	
	close(sockfd);
	return 0;
}