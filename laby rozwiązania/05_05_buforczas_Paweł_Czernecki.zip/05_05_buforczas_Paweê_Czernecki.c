#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Użycie: %s <rozmiar_bufora> <plik_src> <plik_trg>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int rozmiar_bufora = atoi(argv[1]);
    char *plik_src = argv[2];
    char *plik_trg = argv[3];

    FILE *src = fopen(plik_src, "rb");
    if (src == NULL) {
        perror("Nie można otworzyć pliku źródłowego");
        return EXIT_FAILURE;
    }

    FILE *trg = fopen(plik_trg, "wb");
    if (trg == NULL) {
        perror("Nie można otworzyć pliku docelowego");
        fclose(src);
        return EXIT_FAILURE;
    }

    char *bufor = (char *)malloc(rozmiar_bufora);
    if (bufor == NULL) {
        perror("Błąd alokacji bufora");
        fclose(src);
        fclose(trg);
        return EXIT_FAILURE;
    }

    struct timeval start, end;
    gettimeofday(&start, NULL);

    size_t bytes_read, bytes_written;

    while ((bytes_read = fread(bufor, 1, rozmiar_bufora, src)) > 0) {
        bytes_written = fwrite(bufor, 1, bytes_read, trg);
        if (bytes_written != bytes_read) {
            perror("Błąd podczas zapisu do pliku docelowego");
            free(bufor);
            fclose(src);
            fclose(trg);
            return EXIT_FAILURE;
        }
    }

    gettimeofday(&end, NULL);

    free(bufor);
    fclose(src);
    fclose(trg);

    double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1e6;

    printf("Czas kopiowania: %.6f sekund\n", elapsed_time);

    return EXIT_SUCCESS;
}
